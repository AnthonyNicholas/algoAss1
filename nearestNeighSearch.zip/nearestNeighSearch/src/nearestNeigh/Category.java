package nearestNeigh;

/**
 * category of nodes
 * 
 * @author Jeffrey, Youhan
 */
public enum Category {
    RESTAURANT, EDUCATION, HOSPITAL
}
